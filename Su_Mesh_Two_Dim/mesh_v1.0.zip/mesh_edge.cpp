#include <fstream>
#include <iostream>
#include <list>
#include <vector>

// 声明维度DIM为常值
constexpr auto DIM = 2;

// 声明网格单元结构体类型
typedef struct ELEM
{
  int form[DIM + 1]; // 存储单元包含的节点
  int neig[DIM + 1]; // 存储单元的相邻单元，与form[i]对应
} ELEM;

// ELEM结构体初始化
void InitElem(ELEM *elem_init)
{
  for (int i = 0; i <= DIM; i++)
  {
    elem_init->form[i] = -1;
    elem_init->neig[i] = -1;
  }
  return;
}

// 声明网格节点结构体类型
typedef struct NODE
{
  double pos[DIM + 1]; // 节点几何坐标
  int elem;            // 当前网格中包含该节点的任意单元标号
  double spac;         // 对应节点理想单元尺寸值
} NODE;

// NODE结构体初始化
void InitNode(NODE *node_init)
{
  for (int i = 0; i <= DIM; i++)
  {
    node_init->pos[i] = 0; // 节点坐标应该初始化为零
  }
  node_init->elem = -1;
  node_init->spac = -1;
  return;
}

// 声明网格边结构体类型
typedef struct EDGE
{
  int node[DIM]; // 两个节点或者两个边，编号小的始终在[0]，大的则在[1]
  int elem[DIM];
} EDGE;

// EDGE结构体初始化
void InitEdge(EDGE *edge_init)
{
  for (int i = 0; i < DIM; i++)
  {
    edge_init->node[i] = -1;
    edge_init->elem[i] = -1;
  }
  return;
}

// 声明三角形外接圆圆心与半径查找算法
double *FindCenter()
{
  return 0;
}

//  读取输入文件 in.smesh
void ReadInFile(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num)
{
  std::fstream infile;                                     // 声明输入文件流
  infile.open("in.smesh", std::ios::in);                   // 打开in.smesh，并且只能进行读取操作
  std::cout << "Reading from the file......" << std::endl; // 正在读取文件
  if (!infile.is_open())
  {                                        // 判断文件是否存在或者是否成功打开
    std::cout << "error on open in.smesh"; // 文件不能成功打开
    system("pause");
    exit(-1);
  }
  else
  {
    std::cout << "Reading successfully!" << std::endl; // 读取文件成功
    infile >> *node_num;                               // 读取输入节点数
    NODE node_tp;                                      // 声明临时NODE结构体用于压入容器
    int tp;                                            // 声明用于临时存放值的变量
    for (int i = 0; i < *node_num; i++)
    {
      InitNode(&node_tp); // 初始化node_tp
      infile >> tp;
      infile >> node_tp.pos[0] >> node_tp.pos[1] >> node_tp.pos[2]; // 读入节点坐标
      node->push_back(node_tp);                                     // 压入容器node
    }
    infile >> *elem_num; // 读取输入网格单元数
    if (!*elem_num)      // 如果没有输入网格单元，关闭文件退出该程序
    {
      infile.close();
      return;
    }
  }
  infile.close();
  return;
}

// 输出生成网格文件 out.smesh
void OutputFile(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num)
{
  std::fstream outfile;                                       // 声明输出文件流
  outfile.open("out.smesh", std::ios::out | std::ios::trunc); // 创建或者打开out.smesh，如果此文件已经存在, 则打开文件之前把文件长度截断为0
  if (!outfile.is_open())
  {                                        // 判断文件是是否成功打开
    std::cout << "error on open in.smesh"; // 文件不能成功打开
    system("pause");
    exit(-1);
  }
  else // 以tetview网格文件方式输出网格信息
  {
    //* 输出节点信息
    outfile << *node_num << ' ' << DIM + 1 << ' ' << 0 << ' ' << 0 << '\n';
    int node_cnt = 0; // 定义节点输出标号变量，第一个节点标号显然为零
    for (std::vector<NODE>::iterator node_iter = node->begin(); node_iter != node->end();
         ++node_iter) // 使用迭代器遍历node，输出节点信息
    {
      NODE node_tp = *node_iter; // 定义一个结构体，用来临时储存node_iter指向的每一个结构体，便于输出
      outfile << node_cnt << ' ' << node_tp.pos[0] << ' ' << node_tp.pos[1] << ' ' << node_tp.pos[2] << '\n';
      node_cnt += 1; // 每成功输出一个节点，node_cnt++
    }
    //* 输出网格单元信息
    outfile << *elem_num << ' ' << 0 << '\n';
    int elem_NodeNum = 3; // 定义网格单元节点数，显然Delaunay三角化生成的网格单元是三角形有3个节点
    for (std::vector<ELEM>::iterator elem_iter = elem->begin(); elem_iter != elem->end();
         ++elem_iter) // 使用迭代器遍历elem，输出网格单元信息
    {
      ELEM elem_tp = *elem_iter; // 定义一个结构体，用来临时储存node_iter指向的每一个结构体，便于输出
      outfile << elem_NodeNum << ' ' << elem_tp.form[0] << ' ' << elem_tp.form[1] << ' ' << elem_tp.form[2] << '\n';
    }
    outfile << 0 << '\n'
            << 0; // 以tetview网格文件方式输出网格信息
  }
  outfile.close();
  return;
}

// 空腔查找
void FindElemCav(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                 std::vector<ELEM> elem_Cav, NODE node_Insert)
{
  return;
}

// 空腔修复
void RepairCavity(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                  std::vector<ELEM> elem_Cav, NODE node_Insert)
{
  if (*elem_num == 0) // 如果问题域内无网格单元则直接返回
    return;
  return;
}

// 内部点生成
void CreateFieldNodes(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                      std::vector<NODE> *node_Insert, std::vector<int> *elemNum_IncludeNodeIns)
{
  if (*elem_num == 0) // 如果问题域内无网格单元则直接在问题域重心处插入节点
  {
    NODE node_tp;                       // 声明一个用于临时储存生成节点的变量
    InitNode(&node_tp);                 // 初始化node_tp
    for (int i = 0; i < *node_num; i++) // 在单元重心处生成内部点
    {
      node_tp.pos[0] += node->at(i).pos[0];
      node_tp.pos[1] += node->at(i).pos[1];
    }
    node_tp.pos[0] /= *node_num; // 重心
    node_tp.pos[1] /= *node_num;
    node_tp.pos[2] = 0;                    // 二维网格生成默认第三坐标为零
    node_tp.elem = -1;                     // 无单元
    node_tp.spac = -1;                     // 无尺寸值
    node_Insert->push_back(node_tp);       // 将生成的节点压入待插入节点容器
    elemNum_IncludeNodeIns->push_back(-1); // 将-1压入elemNum_IncludeNodeIns代表当前单元不是Delaunay三角化网格单元
    return;
  }
  else
  {
    NODE node_tp; // 声明一个临时储存待插入节点的结构体
    int cnt = 0;  // 定义一个变量，来对网格编号进行计数
    for (std::vector<ELEM>::iterator elem_iter = elem->begin(); elem_iter != elem->end(); ++elem_iter)
    {
      InitNode(&node_tp); // 初始化node_tp
      node_tp.pos[0] = (node->at(elem_iter->form[0]).pos[0] + node->at(elem_iter->form[1]).pos[0] +
                        node->at(elem_iter->form[2]).pos[0]) /
                       3;
      node_tp.pos[1] = (node->at(elem_iter->form[0]).pos[1] + node->at(elem_iter->form[1]).pos[1] +
                        node->at(elem_iter->form[2]).pos[1]) /
                       3;
      node_tp.pos[2] = (node->at(elem_iter->form[0]).pos[2] + node->at(elem_iter->form[1]).pos[2] +
                        node->at(elem_iter->form[2]).pos[2]) /
                       3;
      node_Insert->push_back(node_tp);          // 将生成的节点插入node_Insert
      elemNum_IncludeNodeIns->push_back(cnt++); // 将包含该生成节点的网格单元编号插入elemNum_IncludeNodeIns
    }
  }
  return;
}

// 内部点插入
bool InsertFieldPoint(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                      NODE node_Insert, int elemNum_IncludeNodeIns)
{
  std::vector<ELEM> elem_Insert;        // 创建一个容器，用来储存待插入网格单元
  ELEM elem_tp;                         // 声明一个用于临时储存生成网格单元的变量
  if (*elem_num == 0)                   // 如果当前网格中无网格单元，直接生成网格单元
    for (int i = 0; i < *node_num; i++) // 一个个生成网格单元
    {
      InitElem(&elem_tp); // 初始化elem_tp
      elem_tp.form[0] = i;
      if (i == *node_num - 1) // 循环一圈
        elem_tp.form[1] = 0;
      else
        elem_tp.form[1] = i + 1;
      elem_tp.form[2] = *node_num;    // 生成的所有网格单元其中一个节点总是待插入的节点
      elem_Insert.push_back(elem_tp); // 将当前生成的网格单元压入elem_Insert
    }
  else
  {
    std::vector<ELEM> elem_Cav; // 创建一个容器，用来储存外接圆包含待插入节点node_Insert的网格单元
    FindElemCav(elem, elem_num, node, node_num, elem_Cav, node_Insert);
    RepairCavity(elem, elem_num, node, node_num, elem_Cav, node_Insert);
  }
  for (std::vector<ELEM>::iterator elem_iter = elem_Insert.begin(); elem_iter != elem_Insert.end(); elem_iter++)
  {
    elem->push_back(*elem_iter); // 将elem_Insert中的所有网格单元通过迭代器插入elem中，形成网格单元生成
    *elem_num += 1;              // 每插入一个网格单元记一次数
  }
  return true;
}

// 内部点生成和插入
void AutoRefine(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                std::vector<EDGE> *edge)
{
  std::vector<NODE> node_Insert;           // 创建储存待插入节点的容器
  std::vector<int> elemNum_IncludeNodeIns; // 创建一个容器，用来储存直接包含待插入节点的网格单元编号，标号与node_Insert一一对应
  std::vector<NODE> node_InsSucc;          // 创建一个容器，用来储存成功插入的节点
  /**
   * ! 该处是便于检查运行而设立，若有网格约束则可以删去
   */
  int flag = 0;
  do
  {
    std::vector<NODE>().swap(node_Insert);           // 初始化node_Insert，并释放容器空间
    std::vector<int>().swap(elemNum_IncludeNodeIns); // 初始化elemNum_IncludeNodeIns，并释放容器空间
    std::vector<NODE>().swap(node_InsSucc);          // 初始化node_InsSucc，并释放容器空间
    CreateFieldNodes(elem, elem_num, node, node_num, &node_Insert,
                     &elemNum_IncludeNodeIns); // 内部点生成
    if (!node_Insert.empty())                  // 如果待插入节点容器不为空，则开始插入节点
    {
      for (unsigned long long i = 0; i < node_Insert.size(); i++)
      {
        bool Sign = InsertFieldPoint(elem, elem_num, node, node_num, node_Insert.at(i),
                                     elemNum_IncludeNodeIns.at(i)); // 插入该节点，并得到节点是否成功插入的信息
        if (Sign)
          node_InsSucc.push_back(node_Insert.at(i)); // 如果节点成功插入，则将成功插入的节点放入容器
      }
    }
    if (!node_InsSucc.empty()) // 当成功插入节点后，再将成功插入的节点放入node
      for (std::vector<NODE>::iterator node_iter = node_InsSucc.begin(); node_iter != node_InsSucc.end(); node_iter++)
      {
        node->push_back(*node_iter); // 将node_InsSucc中的所有节点通过迭代器插入node中，形成节点插入
        *node_num += 1;              // 每插入一个节点记一次数
      }
    /**
     * ! 只让程序运行两次生成网格
     */
    flag++;
  } while (!node_InsSucc.empty() && flag <= 1); // 如果该次循环成功插入了节点，则再执行一次循环
  return;
}

int main()
{
  std::vector<ELEM> elem;                                // 创建ELEM结构体类型容器
  int elem_num = -1;                                     // 定义网格单元数，并初始化为-1，-1为未输入网格单元
  std::vector<NODE> node;                                // 创建NODE结构体类型容器
  int node_num = -1;                                     // 定义网格节点数，并初始化为-1，-1为未输入网格节点
  std::vector<EDGE> edge;                                // 创建EDGE结构体类型容器
  ReadInFile(&elem, &elem_num, &node, &node_num);        // 读取输入文件 in.smesh
  AutoRefine(&elem, &elem_num, &node, &node_num, &edge); // 内部点生成和插入
  OutputFile(&elem, &elem_num, &node, &node_num);        // 输出网格信息文件 out.smesh
  return 0;
}