#include <iostream>
#include <algorithm>
#include <iterator>
#include <vector>

using namespace std;

constexpr auto err = 0.00001; // 作为优化判断点是否在三角形内部时计算面积的误差

// 声明两点间距离计算算法
double getDist(double A[], double B[])
{
  return sqrt(pow(A[0] - B[0], 2) + pow(A[1] - B[1], 2));
}

// 声明三角形面积计算算法
double getArea(double A[], double B[], double C[])
{
  double a = getDist(A, B);
  double b = getDist(B, C);
  double c = getDist(A, C);
  double p = (a + b + c) / 2;
  return sqrt(p * (p - a) * (p - b) * (p - c));
}

// 声明判断点是否在三角形内部算法
bool isInTriangle(double A[], double B[], double C[], double node_Insert[])
{
  // 点与三角形三个顶点形成的三个三角形面积相加得到的值与原三角形面积比较，相同则点在三角形内
  double s1 = getArea(A, B, node_Insert);
  double s2 = getArea(B, C, node_Insert);
  double s3 = getArea(A, C, node_Insert);
  double S = getArea(A, B, C);
  if (err > fabs(S - s1 - s2 - s3)) // 注意绝对值
    return true;
  else
    return false;
}

// 声明外接圆半径查找算法
double getExternalRadius(double A[], double B[], double C[])
{
  double a = getDist(A, B);
  double b = getDist(A, C);
  double c = getDist(B, C);
  double p = (a + b + c) / 2;
  double S = sqrt(p * (p - a) * (p - b) * (p - c));
  double radius = a * b * c / (4 * S);
  return radius;
}

// 声明外接圆圆心查找算法
void getExternalCenter(double A[], double B[], double C[], double *center)
{
  double t1 = A[0] * A[0] + A[1] * A[1];
  double t2 = B[0] * B[0] + B[1] * B[1];
  double t3 = C[0] * C[0] + C[1] * C[1];
  double temp = A[0] * B[1] + B[0] * C[1] + C[0] * A[1] - A[0] * C[1] - B[0] * A[1] - C[0] * B[1];
  double x = (t2 * C[1] + t1 * B[1] + t3 * A[1] - t2 * A[1] - t3 * B[1] - t1 * C[1]) / temp / 2;
  double y = (t3 * B[0] + t2 * A[0] + t1 * C[0] - t1 * B[0] - t2 * C[0] - t3 * A[0]) / temp / 2;
  *center = x;
  *(center + 1) = y;
  return;
}

// 声明三角形外接圆圆心与半径查找算法，返回该网格单元的外接圆是否包含该节点
bool CirumsInclude()
{
  // 因为是二维下，直接看x,y坐标就行，并且一个网格单元有三个节点
  double point_Coord[3][2] = {{0, 0}, {0.125, 0}, {0.208333, 0.166667}};
  double radius = getExternalRadius(point_Coord[0], point_Coord[1], point_Coord[2]); // 求外接圆半径
  double center[2];
  double node_judge[] = {0, 0.125};
  getExternalCenter(point_Coord[0], point_Coord[1], point_Coord[2], center); // 求外接圆圆心
  if (getDist(node_judge, center) > radius)
    return false;
  else
    return true;
}

int main(void)
{
  cout << CirumsInclude();
  return 0;
}