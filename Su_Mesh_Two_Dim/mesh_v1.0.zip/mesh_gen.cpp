#include <iostream>
#include <fstream>

constexpr auto DIM = 2;                     // 声明维度DIM为常值
constexpr auto node_perface = 20;           // 每条边平分为10份
constexpr auto node_num = node_perface * 4; // 每个边生成11个点

int main() 
{
  int node_cnt = 0; // 节点编号计数
  double node_size = node_perface;
  double node[node_num][3]; // 节点变量
  for (int i = 0; i < node_perface; i++)
  {
    if (i == 0)
      node[node_cnt][0] = 0;
    else
      node[node_cnt][0] = node[node_cnt - 1][0] + 1 / node_size;
    node[node_cnt][1] = 0;
    node[node_cnt][2] = 0;
    node_cnt++;
  }
  for (int i = 0; i < node_perface; i++)
  {
    if (i == 0)
      node[node_cnt][1] = 0;
    else
      node[node_cnt][1] = node[node_cnt - 1][1] + 1 / node_size;
    node[node_cnt][0] = 1;
    node[node_cnt][2] = 0;
    node_cnt++;
  }
  for (int i = 0; i < node_perface; i++)
  {
    if (i == 0)
      node[node_cnt][0] = 1;
    else
      node[node_cnt][0] = node[node_cnt - 1][0] - 1 / node_size;
    node[node_cnt][1] = 1;
    node[node_cnt][2] = 0;
    node_cnt++;
  }
  for (int i = 0; i < node_perface; i++)
  {
    if (i == 0)
      node[node_cnt][1] = 1;
    else
      node[node_cnt][1] = node[node_cnt - 1][1] - 1 / node_size;
    node[node_cnt][0] = 0;
    node[node_cnt][2] = 0;
    node_cnt++;
  }
  std::fstream outfile;                                       // 声明输出文件流
  outfile.open("in1.smesh", std::ios::out | std::ios::trunc); // 创建或者打开out.smesh，如果此文件已经存在, 则打开文件之前把文件长度截断为0
  if (!outfile.is_open())
  {                                        // 判断文件是是否成功打开
    std::cout << "error on open in.smesh"; // 文件不能成功打开
    system("pause");
    exit(-1);
  }
  else // 以tetview网格文件方式输出网格信息
  {
    //* 输出节点信息
    outfile << node_num <<'\n';
    node_cnt = 0; // 定义节点输出标号变量，第一个节点标号显然为零
    for (int i = 0; i < node_num; i++)
    {
      outfile << node_cnt << ' ' << node[node_cnt][0] << ' ' << node[node_cnt][1] << ' ' << node[node_cnt][2] << '\n';
      node_cnt += 1; // 每成功输出一个节点，node_cnt++
    }
  }
  outfile << 0;
  outfile.close();
  return 0;
}