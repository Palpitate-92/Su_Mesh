-- Lua script.
p=tetview:new()
p:load_plc("C:/Users/20758/Desktop/Mesh_Generation/out.smesh")
rnd=glvCreate(0, 0, 500, 500, "TetView")
p:plot(rnd)
glvWait()
