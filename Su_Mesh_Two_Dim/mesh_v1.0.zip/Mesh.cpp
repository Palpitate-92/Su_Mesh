#include <fstream>
#include <iostream>
#include <list>
#include <vector>

constexpr auto DIM = 2;           // 声明维度DIM为常值
constexpr auto err = 0.00001;     // 作为优化判断点是否在三角形内部时计算面积的误差
constexpr auto spac_ideal = 0.04; // 网格单元边理想长度，只要一条边长度低于该长度，则不予生成

// 声明网格单元结构体类型
typedef struct ELEM
{
  int form[DIM + 1]; // 存储单元包含的节点
  int neig[DIM + 1]; // 存储单元的相邻单元，与form[i]对应
} ELEM;

// ELEM结构体初始化
void InitElem(ELEM *elem_init)
{
  for (int i = 0; i <= DIM; i++)
  {
    elem_init->form[i] = -1;
    elem_init->neig[i] = -1;
  }
  return;
}

/*
 * ！ 快速交换elem结构体的form数组，使其从小到大排列,只针对二维情况！！！
 */
void SwapElem_Form(ELEM *elem_tp)
{
  int a = 0, b = 1, c = 2;
  if (elem_tp->form[a] > elem_tp->form[b])
  {
    std::swap(elem_tp->form[a], elem_tp->form[b]);
    std::swap(elem_tp->neig[a], elem_tp->neig[b]);
  }
  if (elem_tp->form[b] > elem_tp->form[c])
  {
    std::swap(elem_tp->form[b], elem_tp->form[c]);
    std::swap(elem_tp->neig[b], elem_tp->neig[c]);
    if (elem_tp->form[a] > elem_tp->form[b])
    {
      std::swap(elem_tp->form[a], elem_tp->form[b]);
      std::swap(elem_tp->neig[a], elem_tp->neig[b]);
    }
  }
  else
    return;
  return;
}

// 声明网格节点结构体类型
typedef struct NODE
{
  double pos[DIM + 1]; // 节点几何坐标
  int elem;            // 当前网格中包含该节点的任意单元标号
  double spac;         // 对应节点理想单元尺寸值
} NODE;

// NODE结构体初始化
void InitNode(NODE *node_init)
{
  for (int i = 0; i <= DIM; i++)
  {
    node_init->pos[i] = 0; // 节点坐标应该初始化为零
  }
  node_init->elem = -1;
  node_init->spac = -1;
  return;
}

// 声明网格边结构体
typedef struct FACE
{
  int form[2];                            // 显然一条边由两个节点构成
  bool operator==(const FACE &face) const // 重载“==”运算符，用来支持FACE迭代器的find()判断
  {
    return ((face.form[0] == form[0]) && (face.form[1] == form[1])); // 所有值相同才相同
  }
} FACE;

// FACE结构体初始化
void InitFace(FACE *face_init)
{
  face_init->form[0] = -1;
  face_init->form[0] = -1;
}

// 声明两点间距离计算算法
double getDist(double A[], double B[])
{
  return sqrt(pow(A[0] - B[0], 2) + pow(A[1] - B[1], 2));
}

// 声明三角形面积计算算法
double getArea(double A[], double B[], double C[])
{
  double a = getDist(A, B);
  double b = getDist(B, C);
  double c = getDist(A, C);
  double p = (a + b + c) / 2;
  return sqrt(p * (p - a) * (p - b) * (p - c));
}

// 声明判断点是否在三角形内部算法
bool isInTriangle(double A[], double B[], double C[], double node_Insert[])
{
  // 点与三角形三个顶点形成的三个三角形面积相加得到的值与原三角形面积比较，相同则点在三角形内
  double s1 = getArea(A, B, node_Insert);
  double s2 = getArea(B, C, node_Insert);
  double s3 = getArea(A, C, node_Insert);
  double S = getArea(A, B, C);
  if (err > fabs(S - s1 - s2 - s3)) // 注意绝对值
    return true;
  else
    return false;
}

// 声明外接圆半径查找算法
double getExternalRadius(double A[], double B[], double C[])
{
  double a = getDist(A, B);
  double b = getDist(A, C);
  double c = getDist(B, C);
  double p = (a + b + c) / 2;
  double S = sqrt(p * (p - a) * (p - b) * (p - c));
  double radius = a * b * c / (4 * S);
  return radius;
}

// 声明外接圆圆心查找算法
void getExternalCenter(double A[], double B[], double C[], double *center)
{
  double t1 = A[0] * A[0] + A[1] * A[1];
  double t2 = B[0] * B[0] + B[1] * B[1];
  double t3 = C[0] * C[0] + C[1] * C[1];
  double temp = A[0] * B[1] + B[0] * C[1] + C[0] * A[1] - A[0] * C[1] - B[0] * A[1] - C[0] * B[1];
  double x = (t2 * C[1] + t1 * B[1] + t3 * A[1] - t2 * A[1] - t3 * B[1] - t1 * C[1]) / temp / 2;
  double y = (t3 * B[0] + t2 * A[0] + t1 * C[0] - t1 * B[0] - t2 * C[0] - t3 * A[0]) / temp / 2;
  *center = x;
  *(center + 1) = y;
  return;
}

// 声明三角形外接圆圆心与半径查找算法，返回该网格单元的外接圆是否包含该节点
bool CirumsInclude(ELEM elem_tp, std::vector<NODE> *node, NODE node_Insert)
{
  // 因为是二维下，直接看x,y坐标就行，并且一个网格单元有三个节点
  double point_Coord[3][2] = {node->at(elem_tp.form[0]).pos[0], node->at(elem_tp.form[0]).pos[1],
                              node->at(elem_tp.form[1]).pos[0], node->at(elem_tp.form[1]).pos[1],
                              node->at(elem_tp.form[2]).pos[0], node->at(elem_tp.form[2]).pos[1]};
  double radius = getExternalRadius(point_Coord[0], point_Coord[1], point_Coord[2]); // 求外接圆半径
  double center[2];
  getExternalCenter(point_Coord[0], point_Coord[1], point_Coord[2], center); // 求外接圆圆心
  if (getDist(node_Insert.pos, center) > radius)
    return false;
  else
    return true;
}

//  读取输入文件
void ReadInFile(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num)
{
  std::fstream infile;                                     // 声明输入文件流
  infile.open("in1.smesh", std::ios::in);                  // 打开in.smesh，并且只能进行读取操作
  std::cout << "Reading from the file......" << std::endl; // 正在读取文件
  if (!infile.is_open())
  {                                        // 判断文件是否存在或者是否成功打开
    std::cout << "error on open in.smesh"; // 文件不能成功打开
    system("pause");
    exit(-1);
  }
  else
  {
    std::cout << "Reading successfully!" << std::endl; // 读取文件成功
    infile >> *node_num;                               // 读取输入节点数
    NODE node_tp;                                      // 声明临时NODE结构体用于压入容器
    int tp;                                            // 声明用于临时存放值的变量
    for (int i = 0; i < *node_num; i++)
    {
      InitNode(&node_tp); // 初始化node_tp
      infile >> tp;
      infile >> node_tp.pos[0] >> node_tp.pos[1] >> node_tp.pos[2]; // 读入节点坐标
      node->push_back(node_tp);                                     // 压入容器node
    }
    infile >> *elem_num; // 读取输入网格单元数
    if (!*elem_num)      // 如果没有输入网格单元，关闭文件退出该程序
    {
      infile.close();
      return;
    }
  }
  infile.close();
  return;
}

// 输出生成网格文件 out.smesh
void OutputFile(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num)
{
  std::fstream outfile;                                       // 声明输出文件流
  outfile.open("out.smesh", std::ios::out | std::ios::trunc); // 创建或者打开out.smesh，如果此文件已经存在, 则打开文件之前把文件长度截断为0
  if (!outfile.is_open())
  {                                        // 判断文件是是否成功打开
    std::cout << "error on open in.smesh"; // 文件不能成功打开
    system("pause");
    exit(-1);
  }
  else // 以tetview网格文件方式输出网格信息
  {
    //* 输出节点信息
    outfile << *node_num << ' ' << DIM + 1 << ' ' << 0 << ' ' << 0 << '\n';
    int node_cnt = 0; // 定义节点输出标号变量，第一个节点标号显然为零
    for (std::vector<NODE>::iterator node_iter = node->begin(); node_iter != node->end();
         ++node_iter) // 使用迭代器遍历node，输出节点信息
    {
      NODE node_tp = *node_iter; // 定义一个结构体，用来临时储存node_iter指向的每一个结构体，便于输出
      outfile << node_cnt << ' ' << node_tp.pos[0] << ' ' << node_tp.pos[1] << ' ' << node_tp.pos[2] << '\n';
      node_cnt += 1; // 每成功输出一个节点，node_cnt++
    }
    //* 输出网格单元信息
    outfile << *elem_num << ' ' << 0 << '\n';
    int elem_NodeNum = 3; // 定义网格单元节点数，显然Delaunay三角化生成的网格单元是三角形有3个节点
    for (std::vector<ELEM>::iterator elem_iter = elem->begin(); elem_iter != elem->end();
         ++elem_iter) // 使用迭代器遍历elem，输出网格单元信息
    {
      ELEM elem_tp = *elem_iter; // 定义一个结构体，用来临时储存node_iter指向的每一个结构体，便于输出
      outfile << elem_NodeNum << ' ' << elem_tp.form[0] << ' ' << elem_tp.form[1] << ' ' << elem_tp.form[2] << '\n';
    }
    outfile << 0 << '\n'
            << 0;                                     // 以tetview网格文件方式输出网格信息
    std::cout << "Outing successfully!" << std::endl; // 文件输出成功
  }
  outfile.close();
  return;
}

// 空腔查找
void FindElemCav(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                 std::vector<int> *elemNum_Cav, NODE node_Insert, int elemNum_IncludeNodeInitial)
{
  std::vector<int> elemNum_wait;                      // 创建一个容器，用来储存待判断的单元
  std::vector<int> elemNum_succ;                      // 创建一个容器，用来储存判断过的单元
  elemNum_succ.push_back(elemNum_IncludeNodeInitial); // 直接压入待插入节点所处的单元编号到elemNum_succ，不用判断
  for (int i = 0; i < DIM + 1; i++)                   // 首先压入待插入节点所处的单元的相邻单元到elemNum_wait
    if (elem->at(elemNum_IncludeNodeInitial).neig[i] != -1)
      elemNum_wait.push_back(elem->at(elemNum_IncludeNodeInitial).neig[i]);
  while (!elemNum_wait.empty()) // 只要elemNum_wait内有元素就继续查找
  {
    int elemNum_tp = elemNum_wait.front(); // 取出elemNum_wait中的第一个元素并擦除
    elemNum_wait.erase(elemNum_wait.begin());
    bool elem_judge = CirumsInclude(elem->at(elemNum_tp),
                                    node, node_Insert); // 判断该网格单元外接圆是否包含待插入节点
    elemNum_succ.push_back(elemNum_tp);                 // 判断后压入elemNum_succ
    if (elem_judge)                                     // 如果包含，则将该网格压入空腔，并将未判断过的相邻网格单元压入elemNum_wait
    {
      elemNum_Cav->push_back(elemNum_tp); // 将该网格单元编号压入空腔
      for (int i = 0; i < DIM + 1; i++)   // 将该网格单元周围未被判断过的相邻单元压入elemNum_wait
        // 在elemNum_succ内查找elemNum_tp对应网格单元相邻网格单元，如果搜到end()，代表没有找到，即该网格没被判断过
        if (std::find(elemNum_succ.begin(), elemNum_succ.end(), elem->at(elemNum_tp).neig[i]) == elemNum_succ.end())
          if (elem->at(elemNum_tp).neig[i] != -1)
            elemNum_wait.push_back(elem->at(elemNum_tp).neig[i]);
    }
  }
  return;
}

// 空腔修复
void RepairCavity(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                  std::vector<int> *elemNum_Cav, NODE node_Insert)
{
  if (*elem_num == 0) // 如果问题域内无网格单元则直接返回
    return;
  return;
}

// 空腔初始化操作，在elem内中初始化空腔所包含的网格单元
void InitElemCav(std::vector<ELEM> *elem, std::vector<int> *elemNum_Cav)
{
  ELEM elem_tp;       // 创建一个网格单元，用于初始化
  InitElem(&elem_tp); // 初始化
  for (unsigned long long i = 0; i < elemNum_Cav->size(); ++i)
    elem->at(elemNum_Cav->at(i)) = elem_tp;
}

// 查找直接包含插入点的网格单元
int FindElemIncludeNode(std::vector<ELEM> *elem, std::vector<NODE> *node, NODE node_Insert, int elemNum_IncludeNodeInitial)
{
  std::vector<int> elemNum_wait;                      // 创建一个容器，用来储存待判断的网格单元
  std::vector<int> elemNum_succ;                      // 创建一个容器，用来储存判断过的单元
  elemNum_wait.push_back(elemNum_IncludeNodeInitial); // 压入初始网格单元
  while (!elemNum_wait.empty())
  {
    int elemNum_tp = elemNum_wait.front(); // 取出elemNum_wait中的第一个元素并擦除
    elemNum_wait.erase(elemNum_wait.begin());
    double node_num[4][2]; // 定义一个数组，储存网格单元节点与待插入点，便于后面数组值的传递
    for (int i = 0; i < DIM + 1; i++)
    {
      node_num[i][0] = node->at(elem->at(elemNum_tp).form[i]).pos[0];
      node_num[i][1] = node->at(elem->at(elemNum_tp).form[i]).pos[1];
    }
    node_num[3][0] = node_Insert.pos[0];
    node_num[3][1] = node_Insert.pos[1];
    if (isInTriangle(node_num[0], node_num[1], node_num[2], node_num[3])) // 判断待插入点是否在三角形内部
      return elemNum_tp;
    elemNum_succ.push_back(elemNum_tp);
    for (int i = 0; i < DIM + 1; i++) // 将该网格单元周围未被判断过的相邻单元压入elemNum_wait
                                      // 首先判断该单元是否存在于elemNum_wait，如不存在再往下判断
      //  在elemNum_succ内查找elemNum_tp对应网格单元相邻网格单元，如果搜到end()，代表没有找到，即该网格没被判断过
      if (std::find(elemNum_wait.begin(), elemNum_wait.end(), elem->at(elemNum_tp).neig[i]) == elemNum_wait.end())
        if (std::find(elemNum_succ.begin(), elemNum_succ.end(), elem->at(elemNum_tp).neig[i]) == elemNum_succ.end())
          if (elem->at(elemNum_tp).neig[i] != -1)
            elemNum_wait.push_back(elem->at(elemNum_tp).neig[i]);
  }
  return -1;
}

// 查找包含该边的所有网格单元，并更新相邻关系
void FindShell(std::vector<ELEM> *elem, int face_form1, int face_form2)
{
  int cnt = 0;                                          // 定义一个变量，找到一个包含face_form边的网格单元就计数一次
  int elemNum_pos[2][2];                                // 声明一个变量，储存包含face_form边的两个网格单元编号，并且储存在该网格单元中与face_form边相对的节点位置form[pos]
  ELEM elem_tp;                                         // 创建一个用于临时储存待判断单元的ELEM结构体
  for (unsigned long long i = 0; i < elem->size(); i++) // 在elem中寻找包含face_form边的网格单元
  {
    InitElem(&elem_tp);    // 初始化elem_tp
    elem_tp = elem->at(i); // 得到当前待判断单元
    if (elem_tp.form[0] == -1)
      continue; // 显然正常单元不会存在节点编号为-1的情况，只有形成空腔的单元节点编号为-1
    if (elem_tp.form[0] == face_form1)
    {
      if (elem_tp.form[1] == face_form2)
      {
        // 找到一个网格了
        elemNum_pos[cnt][0] = i;
        elemNum_pos[cnt][1] = 2;
        if (++cnt == 2) // 找到两个网格单元后退出循环，因为一条边只会被两个网格单元共享
          break;
        continue;
      }
      else if (elem_tp.form[2] == face_form2)
      {
        // 找到一个网格了
        elemNum_pos[cnt][0] = i;
        elemNum_pos[cnt][1] = 1;
        if (++cnt == 2) // 找到两个网格单元后退出循环，因为一条边只会被两个网格单元共享
          break;
        continue;
      }
    }
    else if (elem_tp.form[1] == face_form1)
      if (elem_tp.form[2] == face_form2)
      {
        // 找到一个网格了
        elemNum_pos[cnt][0] = i;
        elemNum_pos[cnt][1] = 0;
        if (++cnt == 2) // 找到两个网格单元后退出循环，因为一条边只会被两个网格单元共享
          break;
        continue;
      }
  }
  if (cnt == 1) // 如果elemNum_face边是边界边，则不需要更新边界关系，直接返回
    return;
  else if (cnt == 2) // 成功找到两个网格单元,更新该两个网格单元的相邻关系
  {
    elem->at(elemNum_pos[0][0]).neig[elemNum_pos[0][1]] = elemNum_pos[1][0];
    elem->at(elemNum_pos[1][0]).neig[elemNum_pos[1][1]] = elemNum_pos[0][0];
  }
}

// 内部点生成
void CreateFieldNodes(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                      std::vector<NODE> *node_Insert, std::vector<int> *elemNum_IncludeNodeInitial)
{
  if (*elem_num == 0) // 如果问题域内无网格单元则直接在问题域重心处插入节点
  {
    NODE node_tp;                       // 声明一个用于临时储存生成节点的变量
    InitNode(&node_tp);                 // 初始化node_tp
    for (int i = 0; i < *node_num; i++) // 在单元重心处生成内部点
    {
      node_tp.pos[0] += node->at(i).pos[0];
      node_tp.pos[1] += node->at(i).pos[1];
    }
    node_tp.pos[0] /= *node_num; // 重心
    node_tp.pos[1] /= *node_num;
    node_tp.pos[2] = 0;                        // 二维网格生成默认第三坐标为零
    node_tp.elem = -1;                         // 无单元
    node_tp.spac = -1;                         // 无尺寸值
    node_Insert->push_back(node_tp);           // 将生成的节点压入待插入节点容器
    elemNum_IncludeNodeInitial->push_back(-1); // 将-1压入elemNum_IncludeNodeInitial代表当前单元不是Delaunay三角化网格单元
    return;
  }
  else
  {
    NODE node_tp; // 声明一个临时储存待插入节点的结构体
    int cnt = 0;  // 定义一个变量，来对网格编号进行计数
    for (std::vector<ELEM>::iterator elem_iter = elem->begin(); elem_iter != elem->end(); ++elem_iter)
    {
      InitNode(&node_tp); // 初始化node_tp
      node_tp.pos[0] = (node->at(elem_iter->form[0]).pos[0] + node->at(elem_iter->form[1]).pos[0] +
                        node->at(elem_iter->form[2]).pos[0]) /
                       3;
      node_tp.pos[1] = (node->at(elem_iter->form[0]).pos[1] + node->at(elem_iter->form[1]).pos[1] +
                        node->at(elem_iter->form[2]).pos[1]) /
                       3;
      node_tp.pos[2] = (node->at(elem_iter->form[0]).pos[2] + node->at(elem_iter->form[1]).pos[2] +
                        node->at(elem_iter->form[2]).pos[2]) /
                       3;
      node_Insert->push_back(node_tp);              // 将生成的节点插入node_Insert
      elemNum_IncludeNodeInitial->push_back(cnt++); // 将包含该生成节点的网格单元编号插入elemNum_IncludeNodeInitial
    }
    return;
  }
  return;
}

// 内部点插入
bool InsertFieldPoint(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num,
                      NODE node_Insert, int elemNum_IncludeNodeIns)
{
  // std::vector<ELEM> elem_Insert;        // 创建一个容器，用来储存待插入网格单元
  ELEM elem_tp;                         // 声明一个用于临时储存生成网格单元的变量
  if (*elem_num == 0)                   // 如果当前网格中无网格单元，直接生成网格单元
    for (int i = 0; i < *node_num; i++) // 一个个生成网格单元
    {
      InitElem(&elem_tp); // 初始化elem_tp
      elem_tp.form[0] = i;
      if (i == *node_num - 1) // 循环一圈
        elem_tp.form[1] = 0;
      else
        elem_tp.form[1] = i + 1;
      elem_tp.form[2] = *node_num; // 生成的所有网格单元其中一个节点总是待插入的节点
      SwapElem_Form(&elem_tp);     // 交换elem_tp内form数据，使其从小到大排列
      // 直接写入节点elem_tp.form[i]相对边数据到elem_tp.neig[i]
      if (i == 0)
        elem_tp.neig[0] = i + 1, elem_tp.neig[1] = *node_num - 1;
      else if (i == *node_num - 1)
        elem_tp.neig[1] = 0, elem_tp.neig[0] = *node_num - 2;
      else
        elem_tp.neig[0] = i + 1, elem_tp.neig[1] = i - 1;
      elem->push_back(elem_tp); // 将当前生成的网格单元压入elem中，形成网格单元生成
      *elem_num += 1;           // 每插入一个网格单元记一次数
    }
  else // 一般情况下生成网格单元
  {
    std::vector<int> elemNum_Cav;                  // 创建一个空腔容器，用来储存外接圆包含待插入节点node_Insert的网格单元编号
    elemNum_Cav.push_back(elemNum_IncludeNodeIns); // 压入直接包含待插入节点的网格单元编号
    FindElemCav(elem, elem_num, node, node_num, &elemNum_Cav, node_Insert,
                elemNum_IncludeNodeIns); // 空腔查找
    // RepairCavity(elem, elem_num, node, node_num, &elemNum_Cav, node_Insert);//空腔修复
    std::vector<FACE> face_Cav;                                 // 创建一个容器，用来储存空腔边界，一个边由两个节点构成
    for (unsigned long long i = 0; i < elemNum_Cav.size(); i++) // 将所有空腔边界压入face_Cav
                                                                /**
                                                                 * * 在face_Cav内查找当前搜索的网格单元边界，如果搜到end()，代表没有找到，该边是空腔边，可以插入；
                                                                 * * 如果没有搜到搜到end()，代表该边不是空腔边，不予插入，并且在face_Cav内删除该边
                                                                 */
    {
      FACE face_tp;                       // 创建一个结构体，用于临时储存生成的边
      int elemNum_tp = elemNum_Cav.at(i); // 取出空腔内一个网格单元
      // 定义一个变量，储存网格单元所有边，便于后续对边的访问
      int face_Cavtp[3][2] = {{elem->at(elemNum_tp).form[0], elem->at(elemNum_tp).form[1]},  // 显然一个网格单元有三条边
                              {elem->at(elemNum_tp).form[1], elem->at(elemNum_tp).form[2]},  // 取节点编号的时候从小到大排列
                              {elem->at(elemNum_tp).form[0], elem->at(elemNum_tp).form[2]}}; // 便于后边各种查找
      for (int j = 0; j < 3; j++)                                                            // 一个网格单元有三条边
      {
        InitFace(&face_tp); // 初始化face_tp
        face_tp.form[0] = face_Cavtp[j][0];
        face_tp.form[1] = face_Cavtp[j][1];
        std::vector<FACE>::iterator face_Iter; // 创建一个迭代器，便于删除非空腔边界边
        if ((face_Iter = std::find(face_Cav.begin(), face_Cav.end(), face_tp)) == face_Cav.end())
        {
          // 首先根据网格单元边理想长度判断该node_Insert是否能插入
          if ((getDist(node_Insert.pos, node->at(face_tp.form[0]).pos) >= spac_ideal) &&
              (getDist(node_Insert.pos, node->at(face_tp.form[1]).pos) >= spac_ideal))
            face_Cav.push_back(face_tp);
          else // 不符合网格单元边理想长度，不予插入该节点，返回false
            return false;
        } // 显然，该边没有被插入过elemNum_face，说明该边是空腔边界边，插入边
        else
          face_Cav.erase(face_Iter); // 显然，该边被插入过elemNum_face，说明该边不是空腔边界边，删除边
      }
    }
    InitElemCav(elem, &elemNum_Cav);                         // 空腔初始化操作，在elem内中初始化空腔所包含的网格单元
    for (unsigned long long i = 0; i < face_Cav.size(); i++) // 对每个空腔边界进行操作，首先更新空腔边界边的相邻关系
    {
      /**
       * ! 计算边界边上每个点到待插入点距离
       * ! 用约束条件判断是否可以插入该点，只要有一个点距离不满足要求就退出程序，返回上一个程序，并将该点重新压入待插入点，之后再判断
       */
      if (i < elemNum_Cav.size()) // 前elemNum_Cav.size()个边与待插入点生成的网格单元编号采用空腔中删除的网格单元编号
      {
        int elemNum_tp = elemNum_Cav.at(i);                    // 取出空腔内一个网格单元编号
        elem->at(elemNum_tp).form[0] = face_Cav.at(i).form[0]; // 显然可以直接给新生成的网格单元赋节点编号
        elem->at(elemNum_tp).form[1] = face_Cav.at(i).form[1];
        elem->at(elemNum_tp).form[2] = *node_num;                        // 最大的节点编号永远是待插入的节点编号
        FindShell(elem, face_Cav.at(i).form[0], face_Cav.at(i).form[1]); // 查找包含该边的所有网格单元，并更新相邻关系
      }
      else // 之后生成的网格全压入elem中，并赋予新的编号
      {
        ELEM elem_tp1;       // 声明一个ELEM结构体，用于临时储存需要生成的网格单元
        InitElem(&elem_tp1); // 初始化elem_tp1
        elem_tp1.form[0] = face_Cav.at(i).form[0];
        elem_tp1.form[1] = face_Cav.at(i).form[1];
        elem_tp1.form[2] = *node_num; // 最大的节点编号永远是待插入的节点编号
        elem->push_back(elem_tp1);    // 将elem_tp1压入elem中，形成网格单元的生成
        *elem_num += 1;
        FindShell(elem, face_Cav.at(i).form[0], face_Cav.at(i).form[1]); // 查找包含该边的所有网格单元，并更新相邻关系
      }
    }
    int face_tp[2];                                          // 声明一个变量，用来储存待更新的边
    face_tp[1] = *node_num;                                  // 显然待更新边的一个节点总是待插入节点，并且其编号也总是最大
    std::vector<int> elemNum_faceJudge;                      // 创建一个容器，用来储存检查过的空腔边节点
    for (unsigned long long i = 0; i < face_Cav.size(); i++) // 更新插入点与空腔边节点连接形成的边的相邻关系
    {
      // 注意，一个边有2个节点
      // 节点一
      if (find(elemNum_faceJudge.begin(), elemNum_faceJudge.end(), face_Cav.at(i).form[0]) == elemNum_faceJudge.end())
      {
        // 显然，该节点没有被检查过，插入节点，更新该节点形成边的相邻关系
        face_tp[0] = face_Cav.at(i).form[0];
        FindShell(elem, face_tp[0], face_tp[1]);
        elemNum_faceJudge.push_back(face_Cav.at(i).form[0]); // 插入该节点编号到elemNum_faceJudge
        if (elemNum_faceJudge.size() == face_Cav.size())     // 显然只会形成与空腔边界边数量相同的边数量，达到该数量则直接退出循环
          break;
      }
      // 节点二
      if (find(elemNum_faceJudge.begin(), elemNum_faceJudge.end(), face_Cav.at(i).form[1]) == elemNum_faceJudge.end())
      {
        // 显然，该节点没有被检查过，插入节点，更新该节点形成边的相邻关系
        face_tp[0] = face_Cav.at(i).form[1];
        FindShell(elem, face_tp[0], face_tp[1]);
        elemNum_faceJudge.push_back(face_Cav.at(i).form[1]); // 插入该节点编号到elemNum_faceJudge
        if (elemNum_faceJudge.size() == face_Cav.size())     // 显然只会形成与空腔边界边数量相同的边数量，达到该数量则直接退出循环
          break;
      }
    }
  }
  /**
  for (std::vector<ELEM>::iterator elem_iter = elem_Insert.begin(); elem_iter != elem_Insert.end(); elem_iter++)
  {
    elem->push_back(*elem_iter); // 将elem_Insert中的所有网格单元通过迭代器插入elem中，形成网格单元生成
    *elem_num += 1;              // 每插入一个网格单元记一次数
  }
   std::vector<ELEM>().swap(elem_Insert); // 初始化elem_Insert，并释放容器空间
   */
  return true;
}

// 内部点生成和插入
void AutoRefine(std::vector<ELEM> *elem, int *elem_num, std::vector<NODE> *node, int *node_num)
{
  std::vector<NODE> node_Insert; // 创建储存待插入节点的容器
  // 创建一个容器，用来储存生成插入点时直接包含待插入节点的网格单元编号，标号与node_Insert一一对应
  // 该容器作为后续网格变化后再次查找包含某插入节点的网格提供便利，能优化查找时间
  std::vector<int> elemNum_IncludeNodeInitial;
  std::vector<NODE> node_InsSucc; // 创建一个容器，用来储存成功插入的节点
  int flag = 0;
  do
  {
    flag++;
    std::vector<NODE>().swap(node_Insert);               // 初始化node_Insert，并释放容器空间
    std::vector<int>().swap(elemNum_IncludeNodeInitial); // 初始化elemNum_IncludeNodeInitial，并释放容器空间
    std::vector<NODE>().swap(node_InsSucc);              // 初始化node_InsSucc，并释放容器空间
    CreateFieldNodes(elem, elem_num, node, node_num, &node_Insert,
                     &elemNum_IncludeNodeInitial); // 内部点生成
    if (!node_Insert.empty())                      // 如果待插入节点容器不为空，则开始插入节点
    {
      for (unsigned long long i = 0; i < node_Insert.size(); i++)
      {
        int elemNum_IncludeNodeIns = -1; // 定义一个变量，用来表示直接包含待插入节点的网格单元编号
        if (*elem_num != 0)
        {
          elemNum_IncludeNodeIns = FindElemIncludeNode(elem, node, node_Insert.at(i),
                                                       elemNum_IncludeNodeInitial.at(i)); // 用来储存直接包含待插入节点的网格单元编号
          if (elemNum_IncludeNodeIns == -1)                                               // 如果该值为-1，说明程序运行错误
            exit(-1);
        }
        bool Sign = InsertFieldPoint(elem, elem_num, node, node_num, node_Insert.at(i),
                                     elemNum_IncludeNodeIns); // 插入该节点，并得到节点是否成功插入的信息
        if (Sign)
        {
          node_InsSucc.push_back(node_Insert.at(i)); // 如果节点成功插入，则将成功插入的节点放入容器
          node->push_back(node_Insert.at(i));        // 将node_InsSucc中的所有节点通过迭代器插入node中，形成节点插入
          *node_num += 1;                            // 每插入一个节点记一次数
        }
      }
    }
    /**
     * ! 只让程序运行两次生成网格
     */
  } while (!node_InsSucc.empty() ); // 如果该次循环成功插入了节点，则再执行一次循环
  return;
}

int main()
{
  std::vector<ELEM> elem;                         // 创建ELEM结构体类型容器
  int elem_num = -1;                              // 定义网格单元数，并初始化为-1，-1为未输入网格单元
  std::vector<NODE> node;                         // 创建NODE结构体类型容器
  int node_num = -1;                              // 定义网格节点数，并初始化为-1，-1为未输入网格节点
  ReadInFile(&elem, &elem_num, &node, &node_num); // 读取输入文件 in.smesh
  AutoRefine(&elem, &elem_num, &node, &node_num); // 内部点生成和插入
  OutputFile(&elem, &elem_num, &node, &node_num); // 输出网格信息文件 out.smesh
  return 0;
}